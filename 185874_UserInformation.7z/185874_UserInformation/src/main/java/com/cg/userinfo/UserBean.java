package com.cg.userinfo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class UserBean {

	WebDriver driver;
	
	@FindBy(name="txtNM")
	@CacheLookup
	WebElement ApplicantName;
	
	@FindBy(name="bnSubmit")
	@CacheLookup
	WebElement confirmButton;
	
	@FindBy(name="txtFName")
	@CacheLookup
	WebElement firstName;

	@FindBy(name="txtLName")
	@CacheLookup
	WebElement lastName;
	
	@FindBy(name="txtFtName")
	@CacheLookup
	WebElement fatherName;
	
	@FindBy(name="txtDOB")
	@CacheLookup
	WebElement dateOfBirth;
	
	@FindBy(name="rdbML")
	@CacheLookup
	WebElement malegender;
	
	@FindBy(name="rdbFML")
	@CacheLookup
	WebElement femalegender;
	
	@FindBy(name="txtMNo")
	@CacheLookup
	WebElement mobileNo;
	
	@FindBy(name="txtEmailID")
	@CacheLookup
	WebElement emailId;
	
	@FindBy(name="txtLLine")
	@CacheLookup
	WebElement landlineNo;
	
	@FindBy(name="rdbRAddress")
	@CacheLookup
	WebElement Residence;
	
	@FindBy(name="rdbOffAddress")
	@CacheLookup
	WebElement office;
	
	@FindBy(name="resAddress")
	@CacheLookup
	WebElement resAdress;

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getApplicantName() {
		return ApplicantName;
	}

	public void setApplicantName(String applicantName) {
		this.ApplicantName.sendKeys(applicantName);
	}

	public WebElement getConfirmButton() {
		return confirmButton;
	}

	public void setConfirmButton() {
		this.confirmButton.click();
	}

	public WebElement getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public WebElement getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public WebElement getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName.sendKeys(fatherName);
	}

	public WebElement getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth.sendKeys(dateOfBirth);
	}

	public WebElement getMalegender() {
		return malegender;
	}

	public void setMalegender(String malegender) {
		this.malegender.sendKeys(malegender);
	}

	public WebElement getFemalegender() {
		return femalegender;
	}

	public void setFemalegender(String femalegender) {
		this.femalegender.sendKeys(femalegender);
	}

	public WebElement getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo.sendKeys(mobileNo);
	}

	public WebElement getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId.sendKeys(emailId);
	}

	public WebElement getLandlineNo() {
		return landlineNo;
	}

	public void setLandlineNo(String landlineNo) {
		this.landlineNo.sendKeys(landlineNo);
	}

	public WebElement getResidence() {
		return Residence;
	}

	public void setResidence(String residence) {
		this.Residence.sendKeys(residence);
	}

	public WebElement getOffice() {
		return office;
	}

	public void setOffice(String office) {
		this.office.sendKeys(office);
	}

	public WebElement getResAdress() {
		return resAdress;
	}

	public void setResAdress(String resAdress) {
		this.resAdress.sendKeys(resAdress);
	}

	public UserBean(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	
}
