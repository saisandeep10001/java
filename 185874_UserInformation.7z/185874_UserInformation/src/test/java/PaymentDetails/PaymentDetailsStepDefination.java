package PaymentDetails;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.userinfo.PersonalBean;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PaymentDetailsStepDefination {
	 WebDriver driver;
	 private PersonalBean personal;
	 
	@Given("^user is on 'Payment Details' page$")
	public void user_is_on_Payment_Details_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 System.setProperty("webdriver.chrome.driver","C:/Users/csaisand/Desktop/BDD/chromedriver.exe");
         driver = new ChromeDriver();

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        personal = new PersonalBean(driver);

        driver.get("file:///C:/Users/csaisand/Desktop/UserInfoPayment/PaymentDetails.html");
    }


	@When("^user enters invalid card holder name$")
	public void user_enters_invalid_card_holder_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		personal.setCardHolderName("");
		personal.setConfirmButton();
	    //throw new PendingException();
	}

	@Then("^displays 'Please fill the Card holder name'$")
	public void displays_Please_fill_the_Card_holder_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the Card holder name";
		String actualMessage=driver.switchTo().alert().getText();
	    if(expectedMessage.equals(actualMessage))
	            System.out.println("Page card holder Matched...");
	        else
	            System.out.println("Page card holder does not matched...");
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	        //driver.close();
	    //throw new PendingException();
	}

	@When("^user enters invalid debit card number$")
	public void user_enters_invalid_debit_card_number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		personal.setCardHolderName("Sandeep");
		personal.setDebit("");
		personal.setConfirmButton();
	   // throw new PendingException();
	}

	@Then("^displays 'Please fill the Debit card Number'$")
	public void displays_Please_fill_the_Debit_card_Number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the Card holder name";
		String actualMessage=driver.switchTo().alert().getText();
	    if(expectedMessage.equals(actualMessage))
	            System.out.println("Please fill the Debit card Number");
	        else
	            System.out.println("Page debit card number does not matched...");
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	   // throw new PendingException();
	}

	@When("^user enters invalid cvv$")
	public void user_enters_invalid_cvv() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		personal.setCardHolderName("Sandeep");
		personal.setDebit("435656787654");
		personal.setCvv("");
		personal.setConfirmButton();
	    //throw new PendingException();
	}

	@Then("^displays 'Please fill the CVV'$")
	public void displays_Please_fill_the_CVV() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the CVV";
		String actualMessage=driver.switchTo().alert().getText();
	    if(expectedMessage.equals(actualMessage))
	            System.out.println("Please fill the cvv");
	        else
	            System.out.println("Page cvv does not matched...");
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// throw new PendingException();
	}

	@When("^user enters invalid expiration month$")
	public void user_enters_invalid_expiration_month() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		personal.setCardHolderName("Sandeep");
		personal.setDebit("435656787654");
		personal.setCvv("567");
		personal.setMonth("");
		personal.setConfirmButton();
	    //throw new PendingException();
	}

	@Then("^displays 'Please fill expiration month'$")
	public void displays_Please_fill_expiration_month() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill expiration month";
		String actualMessage=driver.switchTo().alert().getText();
	    if(expectedMessage.equals(actualMessage))
	            System.out.println("Please fill expiration month");
	        else
	            System.out.println("Page month does not matched...");
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    //throw new PendingException();
	}

	@When("^user enters invalid expiration year$")
	public void user_enters_invalid_expiration_year() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		personal.setCardHolderName("Sandeep");
		personal.setDebit("435656787654");
		personal.setCvv("567");
		personal.setMonth("july");
		personal.setYear("");
		personal.setConfirmButton();
	   // throw new PendingException();
	}

	@Then("^displays 'Please fill the expiration year'$")
	public void displays_Please_fill_the_expiration_year() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the expiration year";
		String actualMessage=driver.switchTo().alert().getText();
	    if(expectedMessage.equals(actualMessage))
	            System.out.println("Please fill the expiration year");
	        else
	            System.out.println("Page year does not matched...");
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	   // throw new PendingException();
	}

	@When("^user enters valid  payment details$")
	public void user_enters_valid_payment_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		personal.setCardHolderName("Sandeep");
		personal.setDebit("435656787654");
		personal.setCvv("567");
		personal.setMonth("july");
		personal.setYear("2021");
		personal.setConfirmButton();
	    //throw new PendingException();
	}

	@Then("^displays 'Pan Card Registration Done successfully !!!'$")
	public void displays_Pan_Card_Registration_Done_successfully() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.get(" ");
		driver.close();
	   // throw new PendingException();
	}
}
