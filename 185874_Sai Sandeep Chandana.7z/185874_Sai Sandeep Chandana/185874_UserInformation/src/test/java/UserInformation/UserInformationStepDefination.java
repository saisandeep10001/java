package UserInformation;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.userinfo.UserBean;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class UserInformationStepDefination {
	 WebDriver driver;
	 private UserBean user;
	@Given("^user is on 'user information' page$")
	public void user_is_on_user_information_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		  System.setProperty("webdriver.chrome.driver", "C:/Users/csaisand/Desktop/BDD/chromedriver.exe");
	         driver = new ChromeDriver();


	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	        user = new UserBean(driver);

	        driver.get("file:///C:/Users/csaisand/Desktop/UserInfoPayment/UserInformation.html");
	    }

	@When("^user enters invalid applicant name$")
	public void user_enters_invalid_applicant_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		user.setApplicantName("");
		user.setConfirmButton();
	    //throw new PendingException();
	}

	@Then("^displays 'Please fill the Applicant Name '$")
	public void displays_Please_fill_the_Applicant_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the Applicant Name ";
		String actualMessage=driver.switchTo().alert().getText();
	    if(expectedMessage.equals(actualMessage))
	            System.out.println("Please fill the Applicant Name ");
	        else
	            System.out.println("Page Applicant name does not found");
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	   // throw new PendingException();
	}

	@When("^user enters invalid first name$")
	public void user_enters_invalid_first_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		user.setApplicantName("Sand");
		user.setFirstName("");
		user.setConfirmButton();
	   // throw new PendingException();
	}

	@Then("^displays 'Please fill the First Name '$")
	public void displays_Please_fill_the_First_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the First Name ";
		String actualMessage=driver.switchTo().alert().getText();
	    if(expectedMessage.equals(actualMessage))
	            System.out.println("Please fill the First Name ");
	        else
	            System.out.println("Page first name does not found");
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    //throw new PendingException();
	}

	@When("^user enters invalid last name$")
	public void user_enters_invalid_last_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		user.setApplicantName("Sand");
		user.setFirstName("Sai");
		user.setLastName("");
		user.setConfirmButton();
	   // throw new PendingException();
	}

	@Then("^displays 'Please fill the Last Name '$")
	public void displays_Please_fill_the_Last_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the Last Name ";
		String actualMessage=driver.switchTo().alert().getText();
	    if(expectedMessage.equals(actualMessage))
	            System.out.println("Please fill the Last Name ");
	        else
	            System.out.println("Page last name does not found");
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	   // throw new PendingException();
	}

	@When("^user enters invalid father name$")
	public void user_enters_invalid_father_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		user.setApplicantName("Sand");
		user.setFirstName("Sai");
		user.setLastName("chandana");
		user.setFatherName("");
		user.setConfirmButton();
	   // throw new PendingException();
	}

	@Then("^displays 'Please fill the Father Name '$")
	public void displays_Please_fill_the_Father_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the Father Name ";
		String actualMessage=driver.switchTo().alert().getText();
	    if(expectedMessage.equals(actualMessage))
	            System.out.println("Please fill the Father Name ");
	        else
	            System.out.println("Page Applicant name does not found");
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	   // throw new PendingException();
	}

	@When("^user enters invalid date of birth$")
	public void user_enters_invalid_date_of_birth() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		user.setApplicantName("Sand");
		user.setFirstName("Sai");
		user.setLastName("chandana");
		user.setFatherName("sudhakar");
		user.setDateOfBirth("");
		user.setConfirmButton();
	}

	@Then("^displays 'Please fill the DOB'$")
	public void displays_Please_fill_the_DOB() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the DOB";
		String actualMessage=driver.switchTo().alert().getText();
	    if(expectedMessage.equals(actualMessage))
	            System.out.println("Please fill the DOB ");
	        else
	            System.out.println("Page DOB name does not wrong");
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    //throw new PendingException();
	}

	@When("^user enters wrong date of birth$")
	public void user_enters_wrong_date_of_birth() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		user.setApplicantName("Sand");
		user.setFirstName("Sai");
		user.setLastName("chandana");
		user.setFatherName("sudhakar");
		user.setDateOfBirth("07");
		user.setConfirmButton();
	}

	@Then("^displays 'Please Enter valid date\\(dd-MM-yyyy\\)'$")
	public void displays_Please_Enter_valid_date_dd_MM_yyyy() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please Enter valid date(dd-MM-yyyy)";
		String actualMessage=driver.switchTo().alert().getText();
	    if(expectedMessage.equals(actualMessage))
	            System.out.println("Please Enter valid date(dd-MM-yyyy)");
	        else
	            System.out.println("Page DOB name does not found");
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    //throw new PendingException();
	}

	@When("^user enters invalid gender$")
	public void user_enters_invalid_gender() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		user.setApplicantName("Sand");
		user.setFirstName("Sai");
		user.setLastName("chandana");
		user.setFatherName("sudhakar");
		user.setDateOfBirth("14-07-1998");
		user.setMalegender("");
		user.setConfirmButton();
	}

	@Then("^displays 'Please select the Gender'$")
	public void displays_Please_select_the_Gender() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please select the Gender";
		String actualMessage=driver.switchTo().alert().getText();
	    if(expectedMessage.equals(actualMessage))
	            System.out.println("Please select the Gender");
	        else
	            System.out.println("Page gender name does not found");
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    //throw new PendingException();
	}

	@When("^user enters invalid mobile no$")
	public void user_enters_invalid_mobile_no() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		user.setApplicantName("Sand");
		user.setFirstName("Sai");
		user.setLastName("chandana");
		user.setFatherName("sudhakar");
		user.setDateOfBirth("14-07-1998");
		user.setMalegender("male");
		user.setMobileNo("");
		user.setConfirmButton();
	}

	@Then("^displays 'Please fill Mobile no'$")
	public void displays_Please_fill_Mobile_no() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill Mobile no";
		String actualMessage=driver.switchTo().alert().getText();
	    if(expectedMessage.equals(actualMessage))
	            System.out.println("Please fill Mobile no");
	        else
	            System.out.println("Page mobile no does not found");
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	   // throw new PendingException();
	}

	@When("^user enters wrong mobile no$")
	public void user_enters_wrong_mobile_no() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		user.setApplicantName("Sand");
		user.setFirstName("Sai");
		user.setLastName("chandana");
		user.setFatherName("sudhakar");
		user.setDateOfBirth("14-07-1998");
		user.setMalegender("male");
		user.setMobileNo("7998678");
		user.setConfirmButton();
	}

	@Then("^displays 'Please enter valid mobile no'$")
	public void displays_Please_enter_valid_mobile_no() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please enter valid mobile no";
		String actualMessage=driver.switchTo().alert().getText();
	    if(expectedMessage.equals(actualMessage))
	            System.out.println("Please enter valid mobile no");
	        else
	            System.out.println("Page mobile no does not found");
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    //throw new PendingException();
	}

	@When("^user enters invalid email id$")
	public void user_enters_invalid_email_id() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		user.setApplicantName("Sand");
		user.setFirstName("Sai");
		user.setLastName("chandana");
		user.setFatherName("sudhakar");
		user.setDateOfBirth("14-07-1998");
		user.setMalegender("male");
		user.setMobileNo("7998678456");
		user.setEmailId("");
		user.setConfirmButton();
	}

	@Then("^displays 'Please fill the Email id '$")
	public void displays_Please_fill_the_Email_id() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the Email id ";
		String actualMessage=driver.switchTo().alert().getText();
	    if(expectedMessage.equals(actualMessage))
	            System.out.println("Please fill the Email id ");
	        else
	            System.out.println("Page Applicant name does not found");
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	   // throw new PendingException();
	}

	@When("^user enters wrong email id$")
	public void user_enters_wrong_email_id() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		user.setApplicantName("Sand");
		user.setFirstName("Sai");
		user.setLastName("chandana");
		user.setFatherName("sudhakar");
		user.setDateOfBirth("14-07-1998");
		user.setMalegender("male");
		user.setMobileNo("7998678456");
		user.setEmailId("saisans");
		user.setConfirmButton();
	}

	@Then("^displays 'Please enter valid Email id'$")
	public void displays_Please_enter_valid_Email_id() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please enter valid Email id";
		String actualMessage=driver.switchTo().alert().getText();
	    if(expectedMessage.equals(actualMessage))
	            System.out.println("Please enter valid Email id");
	        else
	            System.out.println("Page Applicant name does not found");
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	  //  throw new PendingException();
	}

	@When("^user enters invalid landline no$")
	public void user_enters_invalid_landline_no() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		user.setApplicantName("Sand");
		user.setFirstName("Sai");
		user.setLastName("chandana");
		user.setFatherName("sudhakar");
		user.setDateOfBirth("14-07-1998");
		user.setMalegender("male");
		user.setMobileNo("7998678456");
		user.setEmailId("saisands@gmail.com");
		user.setLandlineNo("");
		user.setConfirmButton();
	}

	@Then("^displays 'please fill the landline no'$")
	public void displays_please_fill_the_landline_no() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="please fill the landline no";
		String actualMessage=driver.switchTo().alert().getText();
	    if(expectedMessage.equals(actualMessage))
	            System.out.println("please fill the landline no");
	        else
	            System.out.println("Page Applicant name does not found");
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	   // throw new PendingException();
	}

	@When("^user enters invalid communication$")
	public void user_enters_invalid_communication() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		user.setApplicantName("Sand");
		user.setFirstName("Sai");
		user.setLastName("chandana");
		user.setFatherName("sudhakar");
		user.setDateOfBirth("14-07-1998");
		user.setMalegender("male");
		user.setMobileNo("7998678456");
		user.setEmailId("saisands@gmail.com");
		user.setLandlineNo("567876");
		user.setResidence("");
		user.setConfirmButton();
	}

	@Then("^displays 'Please select the Type of Communication '$")
	public void displays_Please_select_the_Type_of_Communication() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please select the Type of Communication ";
		String actualMessage=driver.switchTo().alert().getText();
	    if(expectedMessage.equals(actualMessage))
	            System.out.println("Please select the Type of Communication ");
	        else
	            System.out.println("Page Applicant name does not found");
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    //throw new PendingException();
	}

	@When("^user enters invalid address$")
	public void user_enters_invalid_address() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		user.setApplicantName("Sand");
		user.setFirstName("Sai");
		user.setLastName("chandana");
		user.setFatherName("sudhakar");
		user.setDateOfBirth("14-07-1998");
		user.setMalegender("male");
		user.setMobileNo("7998678456");
		user.setEmailId("saisands@gmail.com");
		user.setLandlineNo("789876");
		user.setResAdress("");
		user.setConfirmButton();
	}

	@Then("^displays 'please enter the Addresss'$")
	public void displays_please_enter_the_Addresss() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="please enter the Addresss";
		String actualMessage=driver.switchTo().alert().getText();
	    if(expectedMessage.equals(actualMessage))
	            System.out.println("please enter the Addresss");
	        else
	            System.out.println("Page Applicant name does not found");
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    //throw new PendingException();
	}
	
	@When("^user enters valid  user information details$")
	public void user_enters_valid_user_information_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		user.setApplicantName("Sand");
		user.setFirstName("Sai");
		user.setLastName("chandana");
		user.setFatherName("sudhakar");
		user.setDateOfBirth("14-07-1998");
		user.setMalegender("male");
		user.setMobileNo("7998678456");
		user.setEmailId("saisands@gmail.com");
		user.setLandlineNo("789876");
		user.setResAdress("banglore");
		user.setConfirmButton();
	}

	@Then("^displays 'Personal details are validated'$")
	public void displays_Personal_details_are_validated() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.get("file:///C:/Users/csaisand/Desktop/UserInfoPayment/PaymentDetails.html");
		driver.close();
	}

}
