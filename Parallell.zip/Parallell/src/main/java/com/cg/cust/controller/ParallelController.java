package com.cg.cust.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.cust.bean.Parallel;
import com.cg.cust.exception.ParallelException;
import com.cg.cust.service.ParallelService;

@RestController
public class ParallelController {
	@Autowired
	ParallelService parallelService;
	@RequestMapping("/parallel")
	  public List<Parallel> getParallels() throws ParallelException {
        return parallelService.getAllParallels();
    }
	@RequestMapping(value="/parallel",method=RequestMethod.POST)
	public List<Parallel> addCustomer(@RequestBody Parallel cust)throws ParallelException{
	return parallelService.addParallel(cust);
	}
	@RequestMapping("/parallel/{accountno}")
    public Parallel getCustomerByAccountno(@PathVariable int accountno) throws ParallelException{
             return parallelService.getParallelByAccountno(accountno);
    }

	@PutMapping("/parallel/{accountno}")
	public ResponseEntity<String> updateCustomer(@RequestBody Parallel cust)throws ParallelException{
		parallelService.updateParallel(cust);
		return new ResponseEntity<String>
        ("Parallel Suceessfully update",HttpStatus.OK);
		
	}

	@ExceptionHandler({ParallelException.class})
	public ResponseEntity<String> handleErrors(Exception ex){
		return new ResponseEntity<String>("An Error Occurred"+ex.getMessage(),HttpStatus.CONFLICT);
	}
}
