package com.cg.cust.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.cg.cust.bean.Parallel;
@Repository
public interface ParallelDao extends JpaRepository<Parallel, Integer> {

}
