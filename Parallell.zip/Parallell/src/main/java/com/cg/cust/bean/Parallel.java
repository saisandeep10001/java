package com.cg.cust.bean;

import javax.persistence.Entity;

import javax.persistence.Id;

@Entity
public class Parallel {
	@Id
	private int accountno;
	private String name;
	private int mobileno;
	private int balance;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getMobileno() {
		return mobileno;
	}

	public void setMobileno(int mobileno) {
		this.mobileno = mobileno;
	}

	public int getAccountno() {
		return accountno;
	}

	public void setAccountno(int accountno) {
		this.accountno = accountno;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Customer [name=" + name + ", mobileno=" + mobileno + ", accountno=" + accountno + ", balance=" + balance + "]";
	}
	
	
}
